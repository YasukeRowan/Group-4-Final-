const express = require('express');
const path = require('path');
const database = require('../config/database');
const router = express.Router();

//Adding Comments
router.post('/:id/comments', (req, res)=>{
    const collection = 'comments';
    const PostID = req.params.id;
    const user_data = req.body;
    comment = user_data.comment;
    console.log(PostID)
    console.log(comment);

    //Inserting Data in Comments Document
    database.getDB().collection(collection).insertOne({
        'comment': comment,
        'post_id': PostID,
    }, (err, result)=>{
        if(err){
            console.log(err);
        }else {
            res.json({result : result, document : result.ops[0]})
        }
    })
});

//Loading Comments
router.get('/:id/comments', (req, res)=>{
    const collection = 'comments';
    const PostID = req.params.id;
    database.getDB().collection(collection).find({"post_id": PostID}).toArray((err, documents)=>{
        if(err){
            console.log(err)
        }else{
            console.log(documents);
            res.json(documents);
        }
    })

})